import { base44 } from './base44Client';


export const Leader = base44.entities.Leader;

export const Event = base44.entities.Event;

export const Meeting = base44.entities.Meeting;

export const Testimony = base44.entities.Testimony;

export const GalleryImage = base44.entities.GalleryImage;

export const Ministry = base44.entities.Ministry;

export const WebsiteSettings = base44.entities.WebsiteSettings;

export const SpeakerProfile = base44.entities.SpeakerProfile;

export const CoreBelief = base44.entities.CoreBelief;

export const SupportInfo = base44.entities.SupportInfo;



// auth sdk:
export const User = base44.auth;